//
//  GrocerySections.swift
//  Kalla_GroceryApp
//
//  Created by Kalla,Muralidhar Reddy on 4/5/22.
//

import Foundation
import UIKit

struct GrocerySections{
    
var section = [GroceryItem]()
var items_Array = [GroceryItem]()
}

struct GroceryItem{
    
    var itemName = ""
    var itemImage: UIImage?
    var itemInfo = ""
    
}

